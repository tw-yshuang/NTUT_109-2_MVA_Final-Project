import pandas as pd
import matplotlib.pyplot as plt
import cv2
import numpy as np


df = pd.read_csv('train.csv')
en_pix = df['EncodedPixels'] #第3行
en_pix = en_pix[304]
print(en_pix)


print(len(en_pix.split(' ')))
en_pix.split(' ')

rle = list(map(int, en_pix.split(' ')))

pixel,pixel_count = [],[]
[pixel.append(rle[i]) if i%2==0 else pixel_count.append(rle[i]) for i in range(1, len(rle))]
print('pixel starting points:\n',pixel)
print('pixel counting:\n', pixel_count)

rle_pixels = [list(range(pixel[i],pixel[i]+pixel_count[i])) for i in range(1, len(pixel))]
print('rle_pixels\n:', rle_pixels)

rle_mask_pixels = sum(rle_pixels,[]) 
print('rle mask pixels:\n', rle_mask_pixels)


img = cv2.imread(r'3\0af6b34a8.jpg')
plt.imshow(img)
plt.show()

mask_img = np.zeros((256*1600,1), dtype=int)
mask_img[rle_mask_pixels] = 255
l,b=cv2.imread(r'3\0af6b34a8.jpg').shape[0], cv2.imread(r'3\0af6b34a8.jpg').shape[1]
mask = np.reshape(mask_img, (b, l)).T
plt.imshow(mask)
plt.show()


